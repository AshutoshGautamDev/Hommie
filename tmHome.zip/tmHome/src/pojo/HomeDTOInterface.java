package pojo;

import java.util.List;

public interface HomeDTOInterface {
   void addRoom(RoomDTOInterface var1);

   void setRooms(List<RoomDTOInterface> var1);

   List<RoomDTOInterface> getRooms();
}
    