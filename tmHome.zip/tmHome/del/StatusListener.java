//package simulator.interfaces;
public interface StatusListener extends java.io.Serializable
{
public void onStatusChanged(StatusEvent se);
}
