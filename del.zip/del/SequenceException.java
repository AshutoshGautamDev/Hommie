//package dataEntry.util;
public class SequenceException extends Exception
{
public SequenceException(String message)
{
super(message);
}
}
