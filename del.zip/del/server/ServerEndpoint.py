import tornado.ioloop
import tornado.web
import tornado.websocket
import sys
import json
class HomeDTO:
 def __init__(self):
  self.rooms=[];
class RoomDTO:
 def __init__(self):
  self.name="";
  self.id=0;
  self.boards=[];
class BoardDTO:
 def __init__(self):
  self.roomName="";
  self.roomId=0;
  self.name="";
  self.id=0;
  self.status=False;
  self.components=[];
class ComponentDTO:
 def __init__(self):
  self.roomName="";
  self.roomId=0;
  self.boardName="";
  self.boardId=None;
  self.name="";
  self.id=0;
def populateDataStructure():
 global r
 global b
 global c
 global h
 js= open('home.json');
 pd=json.load(js);
 for home,rooms in pd.items():
  h=HomeDTO()
  for room in rooms:
   r=RoomDTO()
   for v,k in room.items():
    if(isinstance(k,list)):
     for board in k:
      b=BoardDTO()
      for i,j in board.items():
       if(isinstance(j,list)):
        for component in j:
         c=ComponentDTO()
         for x,y in component.items():
          if x=="id":
           c.id=y
          if x=="name":
           c.name=y
          if x=="status":
           c.status=y
          if x=="minLevel":
           c.min=y
          if x=="minLevel":
           c.max=y
          if x=="regulatable":
           c.regulatable=y
          if x=="roomName":
           c.roomName=y
          if x=="roomId":
           c.roomId=y
          if x=="boardName":
           c.boardName=y
          if x=="boardId":
           c.boardId=y

         b.components.append(c)
       else:
         if i=="id":
          b.id=j
         if i=="name":
          b.name=j
         if i=="roomName":
          b.roomName=j
         if i=="roomId":
          b.roomId=j
      r.boards.append(b)
    else:
     if v=='id':
      r.id=k;
     if v=='name':
      r.name=k
   h.rooms.append(r)
class IndexHandler(tornado.web.RequestHandler):
 def get(self):
  self.render("""index.html""");
class JsonHandler(tornado.web.RequestHandler):
 def get(self):
  self.render('Home.json'); 
class SimpleWebSocket(tornado.websocket.WebSocketHandler):
 dict=dict([])
 connections = set()
 def check_origin(self, origin):
    return True
 def open(self):
  self.connections.add(self)
  print('Connected');
 def on_message(self, message):
  print(message);
  cJson=json.loads(message);
  for k,v in cJson.items():
   print(k,v);
  print(type(cJson)); 
 def on_close(self):
  self.connections.remove(self)
  print('Disconnected');
def make_app():
 return tornado.web.Application([
 (r"/websocket", SimpleWebSocket),
 (r"/",IndexHandler),
 (r"/requestJson",JsonHandler)
 ])
if __name__ == "__main__":
 try:
  populateDataStructure();
  app = make_app()
  print(len(h.rooms));
  print('Server Instantiated,Listening On Port 8888 ....');
  app.listen(8888)
  tornado.ioloop.IOLoop.current().start()
 except KeyboardInterrupt as ke:
  sys.exit()
