import json;
import collections;
class HomeDTO:
 def __init__(self):
  self.rooms=set([]); 
class RoomDTO:
 def __init__(self):
  self.name="";
  self.id=0;
  self.boards=[];
class BoardDTO:
 def __init__(self):
  self.name="";
  self.id=0;
  self.status=False;
  self.components=[];
class ComponentDTO:
 def __init__(self):
  self.name="";
  self.id=0;
def main():
 count=0;
 h=HomeDTO();
 js= open('home.json');
 pd=json.load(js);
 for home,rooms in pd.items(): 
  for room in rooms:
   r=RoomDTO();
   for v,k in room.items():
    if(isinstance(k,list)):
     for board in k:
      for i,j in board.items():
       if(isinstance(j,list)):
        for component in j:
         for x,y in component.items():
          print("%s:%s"%(x,y));
       else:
        print("%s:%s"%(i,j));
    else:
     if(v=="name"):
      r.name=k;
     if(v=="id"):
      r.id=k;      
     h.rooms.add(r);
     #print("%s:%s"%(v,k));
 print("--------------------------------------------------");
 for r in h.rooms:
  print(r.id);
  print(r.name);
if __name__ =='__main__':
 main();